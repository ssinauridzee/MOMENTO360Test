package ge.diskscope.app;

import android.content.*;
import android.database.*;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.*;

/** Read-only provider for opening user-selected files in external apps. */
public class FileSharingProvider extends ContentProvider {
    private File resolve(Uri u) throws FileNotFoundException {
        String raw=u.getLastPathSegment();
        if(raw==null)throw new FileNotFoundException("Missing path");
        File file=new File(raw);
        try{
            String target=file.getCanonicalPath();
            String shared=android.os.Environment.getExternalStorageDirectory().getCanonicalPath();
            boolean allowed=target.startsWith(shared+File.separator);
            if(!allowed){File[] ext=getContext().getExternalFilesDirs(null);if(ext!=null)for(File dir:ext){
                if(dir==null)continue;String p=dir.getCanonicalPath();int idx=p.indexOf("/Android/");
                if(idx>0&&target.startsWith(p.substring(0,idx)+File.separator)){allowed=true;break;}
            }}
            if(!allowed||!file.isFile()||!file.canRead())throw new FileNotFoundException("Restricted file");
            return file;
        }catch(IOException ex){throw new FileNotFoundException(ex.getMessage());}
    }
    @Override public boolean onCreate(){return true;}
    @Override public String getType(Uri uri){try{String t=java.net.URLConnection.guessContentTypeFromName(resolve(uri).getName());return t==null?"application/octet-stream":t;}catch(Exception ex){return "application/octet-stream";}}
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException{
        if(!"r".equals(mode))throw new FileNotFoundException("Read-only");
        return ParcelFileDescriptor.open(resolve(uri),ParcelFileDescriptor.MODE_READ_ONLY);
    }
    @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String order){
        try{File f=resolve(uri);String[] cols=projection==null?new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}:projection;
            MatrixCursor c=new MatrixCursor(cols);Object[] row=new Object[cols.length];for(int i=0;i<cols.length;i++){
                if(OpenableColumns.DISPLAY_NAME.equals(cols[i]))row[i]=f.getName();else if(OpenableColumns.SIZE.equals(cols[i]))row[i]=f.length();
            }c.addRow(row);return c;
        }catch(FileNotFoundException ex){return null;}
    }
    @Override public Uri insert(Uri u,ContentValues v){throw new UnsupportedOperationException();}
    @Override public int update(Uri u,ContentValues v,String s,String[] a){return 0;}
    @Override public int delete(Uri u,String s,String[] a){return 0;}
}
