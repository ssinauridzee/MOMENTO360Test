package ge.diskscope.app;

import android.os.Handler;
import android.os.Looper;
import java.io.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** No files are changed by this scanner. Hashing only runs on same-size candidates. */
public final class ScannerEngine {
    public static final String[] CATEGORIES = {"ფოტოები", "ვიდეოები", "აუდიო", "დოკუმენტები", "არქივები", "APK", "სხვა"};
    private static final Set<String> IMG = extSet("jpg jpeg png gif bmp webp heic heif dng raw tif tiff avif");
    private static final Set<String> VID = extSet("mp4 mkv mov avi webm 3gp m4v mpg mpeg ts");
    private static final Set<String> AUD = extSet("mp3 wav ogg flac aac m4a wma amr opus");
    private static final Set<String> DOC = extSet("pdf doc docx xls xlsx ppt pptx txt rtf csv md odt ods odp epub psd ai svg json xml html css js py java kt zipx");
    private static final Set<String> ARC = extSet("zip rar 7z tar gz bz2 xz iso cab apkx");
    private static Set<String> extSet(String s) { return new HashSet<>(Arrays.asList(s.split(" "))); }
    public static String category(File file) {
        String n=file.getName().toLowerCase(Locale.ROOT); int dot=n.lastIndexOf('.');
        String ext=dot < 0 ? "" : n.substring(dot+1);
        if(IMG.contains(ext))return "ფოტოები";
        if(VID.contains(ext))return "ვიდეოები";
        if(AUD.contains(ext))return "აუდიო";
        if("apk".equals(ext))return "APK";
        if(ARC.contains(ext))return "არქივები";
        if(DOC.contains(ext))return "დოკუმენტები";
        return "სხვა";
    }
    public static class Item {
        public final File file;
        public final long size;
        public final long modified;
        public final String cat;
        public Item(File f) { file=f; size=Math.max(0,f.length()); modified=f.lastModified(); cat=category(f); }
    }
    public static class Group {
        public final List<Item> items;
        public final long reclaimable;
        public final String hash;
        Group(List<Item> items,String hash) { this.items=items; this.hash=hash; this.reclaimable=(items.size()-1L)*items.get(0).size; }
    }
    public static class Result {
        public final List<Item> files=new ArrayList<>();
        public final List<Group> duplicates=new ArrayList<>();
        public final Map<String,Long> bytes=new LinkedHashMap<>();
        public final Map<String,Integer> count=new LinkedHashMap<>();
        public int folders; public long totalBytes; public long reclaimable; public int extraCopies;
        public int skippedFolders; public boolean cancelled; public String error="";
        Result() { for(String c:CATEGORIES){bytes.put(c,0L);count.put(c,0);} }
    }
    public interface Listener {
        void progress(int files,int folders,long bytes,String current,boolean hashing);
        void complete(Result result);
    }
    private final Handler main=new Handler(Looper.getMainLooper());
    private final AtomicBoolean cancelled=new AtomicBoolean(false);
    public void cancel(){cancelled.set(true);}
    public boolean isCancelled(){return cancelled.get();}
    public void scan(List<File> roots,Listener listener) {
        cancelled.set(false);
        new Thread(()->{
            Result result=new Result();
            try { walk(roots,result,listener); if(!cancelled.get()) hashDuplicates(result,listener); }
            catch(Exception e){ result.error=e.getClass().getSimpleName()+": "+e.getMessage(); }
            result.cancelled=cancelled.get();
            main.post(()->listener.complete(result));
        },"DiskScope-Scanner").start();
    }
    private void walk(List<File> roots,Result result,Listener l){
        ArrayDeque<File> stack=new ArrayDeque<>();
        for(File f:roots)if(f!=null&&f.exists())stack.push(f);
        Set<String> visited=new HashSet<>();
        long lastUpdate=0;
        while(!stack.isEmpty()&&!cancelled.get()){
            File f=stack.pop();
            if(f.isDirectory()){
                try { if(!visited.add(f.getCanonicalPath()))continue; }catch(Exception ex){continue;}
                String name=f.getName();
                if("DiskScopeTrash".equals(name)) continue;
                String path=f.getAbsolutePath().replace('\\','/');
                if(path.endsWith("/Android/data")||path.endsWith("/Android/obb")) {result.skippedFolders++;continue;}
                result.folders++;
                File[] list;
                try{list=f.listFiles();}catch(SecurityException ex){list=null;}
                if(list==null){result.skippedFolders++; continue;}
                for(File child:list) if(child!=null)stack.push(child);
            } else if(f.isFile() && f.canRead()) {
                Item item=new Item(f); result.files.add(item);
                result.totalBytes+=item.size;
                result.bytes.put(item.cat,result.bytes.get(item.cat)+item.size);
                result.count.put(item.cat,result.count.get(item.cat)+1);
            }
            long now=android.os.SystemClock.elapsedRealtime();
            if(now-lastUpdate>170){
                lastUpdate=now; emit(l,result.files.size(),result.folders,result.totalBytes,f.getName(),false);
            }
        }
        emit(l,result.files.size(),result.folders,result.totalBytes,"ფაილების შედარება",true);
    }
    private void hashDuplicates(Result r,Listener l) {
        Map<Long,List<Item>> bySize=new HashMap<>();
        for(Item i:r.files)if(i.size>0)bySize.computeIfAbsent(i.size,k->new ArrayList<>()).add(i);
        int processed=0; long last=0;
        for(List<Item> candidates:bySize.values()){
            if(cancelled.get())break;
            if(candidates.size()<2)continue;
            Map<String,List<Item>> hashes=new HashMap<>();
            for(Item item:candidates){
                if(cancelled.get())break;
                String hash=sha256(item.file);
                if(hash!=null)hashes.computeIfAbsent(hash,k->new ArrayList<>()).add(item);
                processed++;
                long now=android.os.SystemClock.elapsedRealtime();
                if(now-last>180){last=now;emit(l,r.files.size(),r.folders,r.totalBytes,"შემოწმდა: "+processed+" • "+item.file.getName(),true);}
            }
            for(Map.Entry<String,List<Item>> e:hashes.entrySet())if(e.getValue().size()>1){
                List<Item> arr=e.getValue();arr.sort(Comparator.comparing(x->x.file.getAbsolutePath()));
                Group g=new Group(arr,e.getKey());r.duplicates.add(g);
                r.reclaimable+=g.reclaimable;r.extraCopies+=arr.size()-1;
            }
        }
        r.duplicates.sort((a,b)->Long.compare(b.reclaimable,a.reclaimable));
    }
    private String sha256(File file){
        try(InputStream in=new BufferedInputStream(new FileInputStream(file))){
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            byte[] buffer=new byte[65536];int n;
            while((n=in.read(buffer))!=-1){if(cancelled.get())return null;md.update(buffer,0,n);}
            byte[] d=md.digest();StringBuilder b=new StringBuilder(64);
            for(byte v:d)b.append(String.format(Locale.US,"%02x",v & 255));
            return b.toString();
        }catch(Exception e){return null;}
    }
    private void emit(Listener l,int n,int f,long b,String current,boolean hashing){main.post(()->l.progress(n,f,b,current,hashing));}
}
