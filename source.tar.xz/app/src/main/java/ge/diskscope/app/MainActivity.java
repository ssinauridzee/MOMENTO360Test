package ge.diskscope.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.*;
import android.text.method.ScrollingMovementMethod;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final int NAVY=Color.rgb(28,38,72), PURPLE=Color.rgb(97,81,216), PINK=Color.rgb(233,77,143);
    private static final int MUTED=Color.rgb(111,123,149), BG=Color.rgb(247,248,253), WHITE=Color.WHITE;
    private static final int BORDER=Color.rgb(231,235,245), GREEN=Color.rgb(27,170,135);
    private LinearLayout shell, page, nav;
    private ScrollView scroll;
    private int tab=0;
    private volatile boolean running=false;
    private final ScannerEngine engine=new ScannerEngine();
    private ScannerEngine.Result result;
    private final ArrayList<File> scanRoots=new ArrayList<>();
    private final LinkedHashSet<String> selected=new LinkedHashSet<>();
    private String category="ყველა"; private String search="";
    private int pageCount=100;
    private TextView progressLabel, progressCount;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private int lastFiles=0,lastFolders=0;private long lastBytes=0;
    private String lastItem="";private boolean hashing=false;
    private final String[] tabTitles={"მთავარი","ფაილები","დუბლიკატები","დიდი","ურნა"};
    private final String[] tabIcons={"⌂","▤","▣","◫","♻"};

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        scanRoots.addAll(storageRoots());
        buildShell();render();
    }
    private int d(float x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    private TextView text(String value,int sp,int color,boolean bold){
        TextView v=new TextView(this);v.setText(value);v.setTextSize(sp);v.setTextColor(color);v.setIncludeFontPadding(true);
        if(bold)v.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
        v.setGravity(Gravity.CENTER_VERTICAL);return v;
    }
    private GradientDrawable bg(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(d(radius));return g;}
    private GradientDrawable outline(int color,int border,int radius){GradientDrawable g=bg(color,radius);g.setStroke(d(1),border);return g;}
    private GradientDrawable gradient(int a,int b,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});g.setCornerRadius(d(radius));return g;}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:d(w),h<0?h:d(h));}
    private void pad(View v,int l,int t,int r,int b){v.setPadding(d(l),d(t),d(r),d(b));}
    private void margin(LinearLayout parent,View child,int l,int t,int r,int b){LinearLayout.LayoutParams p=lp(-1,-2);p.setMargins(d(l),d(t),d(r),d(b));parent.addView(child,p);}
    private void space(LinearLayout l,int h){l.addView(new View(this),lp(1,h));}
    private void buildShell(){
        shell=vertical();shell.setBackgroundColor(BG);setContentView(shell);
        scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);
        shell.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        page=vertical();pad(page,18,20,18,25);scroll.addView(page);
        nav=horizontal();pad(nav,6,7,6,7);nav.setBackground(outline(WHITE,BORDER,0));shell.addView(nav,lp(-1,66));
    }
    private void render(){
        if(page==null)return;
        page.removeAllViews();
        header();
        if(tab==0)home();
        else if(tab==1)filePage(false);
        else if(tab==2)duplicatePage();
        else if(tab==3)filePage(true);
        else trashPage();
        bottomNav();
    }
    private void header(){
        LinearLayout top=horizontal();
        TextView logo=text("◈",27,PURPLE,true);logo.setGravity(Gravity.CENTER);logo.setBackground(bg(0xFFEBE8FF,16));
        top.addView(logo,lp(44,44));
        LinearLayout titles=vertical();pad(titles,12,0,0,0);
        titles.addView(text("DiskScope",25,NAVY,true));
        titles.addView(text("ფაილების ინტელექტუალური სკანერი",11,MUTED,false));
        top.addView(titles,new LinearLayout.LayoutParams(0,-2,1));
        TextView dot=text("● ოფლაინ",11,GREEN,true);pad(dot,10,9,10,9);dot.setBackground(bg(0xFFE7F8F2,24));top.addView(dot);
        page.addView(top);
        space(page,23);
    }
    private void heading(String a,String b){
        page.addView(text(a,23,NAVY,true));
        if(b!=null){TextView t=text(b,13,MUTED,false);pad(t,0,5,0,0);page.addView(t);}space(page,17);
    }
    private void home(){
        LinearLayout hero=vertical();pad(hero,20,23,20,21);
        hero.setBackground(gradient(0xFF7268E9,0xFF5148C9,26));
        TextView note=text("თქვენი ფაილები — სრული კონტროლით",14,0xFFE9E7FF,true);
        hero.addView(note);space(hero,13);
        TextView circle=text(running?"◌":"◎",66,WHITE,false);circle.setGravity(Gravity.CENTER);
        circle.setBackground(outline(0x227C76FF,0x888E88FF,100));
        LinearLayout.LayoutParams cir=lp(146,146);cir.gravity=Gravity.CENTER;hero.addView(circle,cir);
        space(hero,13);
        TextView state=text(running?(hashing?"დუბლიკატების შემოწმება...":"მიმდინარეობს სკანირება..."):
            result!=null?"სკანირება დასრულებულია":"აირჩიე საცავი და დაიწყე",19,WHITE,true);
        state.setGravity(Gravity.CENTER);hero.addView(state);
        progressCount=text(running?lastFiles+" ფაილი • "+size(lastBytes):result==null?"მონაცემები ჯერ არ არის":result.files.size()+" ფაილი • "+size(result.totalBytes),14,0xFFE7E5FF,false);
        progressCount.setGravity(Gravity.CENTER);pad(progressCount,0,6,0,0);hero.addView(progressCount);
        progressLabel=text(running?lastItem:"",12,0xFFE6E3FF,false);progressLabel.setSingleLine(true);progressLabel.setEllipsize(TextUtils.TruncateAt.MIDDLE);progressLabel.setGravity(Gravity.CENTER);
        pad(progressLabel,8,5,8,0);hero.addView(progressLabel);
        if(running){ProgressBar busy=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);busy.setIndeterminate(true);busy.setIndeterminateTintList(ColorStateList.valueOf(WHITE));
            LinearLayout.LayoutParams p=lp(-1,4);p.topMargin=d(14);hero.addView(busy,p);}
        space(hero,16);
        TextView choose=button("▤   "+scopeTitle(),NAVY,true);choose.setBackground(bg(WHITE,15));hero.addView(choose,lp(-1,48));
        choose.setOnClickListener(v->chooseRoot());
        space(hero,9);
        TextView run=button(running?"შეჩერება":"სკანირების დაწყება",0xFFFFFFFF,true);run.setBackground(outline(0x335D50BF,0xFFACA4FF,14));hero.addView(run,lp(-1,48));
        run.setOnClickListener(v->{if(running){engine.cancel();Toast.makeText(this,"სკანირება ჩერდება...",Toast.LENGTH_SHORT).show();}else startScan();});
        page.addView(hero);
        space(page,22);
        sectionTitle("მიმოხილვა",null);
        LinearLayout row1=horizontal();statCard(row1,"ფაილები",result==null?"—":String.format(Locale.US,"%,d",result.files.size()),"▤",0xFFEEEAFE,PURPLE);
        statCard(row1,"ფოლდერები",result==null?"—":String.format(Locale.US,"%,d",result.folders),"▥",0xFFE7F5FE,0xFF3789D9);
        page.addView(row1,lp(-1,-2));space(page,10);
        LinearLayout row2=horizontal();statCard(row2,"ჯამური ზომა",result==null?"—":size(result.totalBytes),"◉",0xFFFFEFF5,PINK);
        statCard(row2,"დუბლიკატები",result==null?"—":size(result.reclaimable),"♧",0xFFE6F8F0,GREEN);
        page.addView(row2,lp(-1,-2));space(page,23);
        sectionTitle("კატეგორიები",result==null?null:"ფაილების მოცულობა და რაოდენობა");
        if(result==null){empty("სკანირების შემდეგ აქ გამოჩნდება რეალური კატეგორიები.");}
        else{
            for(String c:ScannerEngine.CATEGORIES){final String cat=c;long b=result.bytes.get(c);int n=result.count.get(c);
                if(n==0)continue;
                LinearLayout item=horizontal();pad(item,14,13,14,13);item.setBackground(outline(WHITE,BORDER,15));
                TextView ico=iconText(categoryIcon(c),c);item.addView(ico,lp(43,43));
                LinearLayout detail=vertical();pad(detail,12,0,0,0);detail.addView(text(c,15,NAVY,true));detail.addView(text(n+" ფაილი",12,MUTED,false));item.addView(detail,new LinearLayout.LayoutParams(0,-2,1));
                item.addView(text(size(b)+"  ›",13,PURPLE,true));
                margin(page,item,0,0,0,9);
                item.setOnClickListener(v->{category=cat;tab=1;pageCount=100;render();scroll.scrollTo(0,0);});
            }
        }
        if(result!=null&&result.skippedFolders>0){space(page,10);page.addView(text("შენიშვნა: "+result.skippedFolders+" საქაღალდე მიუწვდომელია სისტემური შეზღუდვების გამო.",12,MUTED,false));}
    }
    private void sectionTitle(String t,String sub){
        TextView title=text(t,17,NAVY,true);page.addView(title);
        if(sub!=null){TextView s=text(sub,12,MUTED,false);pad(s,0,3,0,10);page.addView(s);}else space(page,12);
    }
    private void statCard(LinearLayout line,String name,String value,String icon,int iconBg,int iconColor){
        LinearLayout card=vertical();pad(card,15,14,12,14);card.setBackground(outline(WHITE,BORDER,18));
        TextView i=text(icon,19,iconColor,true);i.setGravity(Gravity.CENTER);i.setBackground(bg(iconBg,12));card.addView(i,lp(38,38));space(card,10);
        card.addView(text(value,19,NAVY,true));space(card,3);card.addView(text(name,12,MUTED,false));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.setMargins(d(0),0,d(5),0);line.addView(card,p);
    }
    private TextView iconText(String icon,String type){
        int tint=PURPLE,color=0xFFEEEAFE;
        if(type.equals("ვიდეოები")){tint=PINK;color=0xFFFFE8F0;}
        if(type.equals("აუდიო")){tint=0xFF269B86;color=0xFFE5F8F2;}
        if(type.equals("დოკუმენტები")){tint=0xFF3289CE;color=0xFFE8F5FF;}
        if(type.equals("არქივები")){tint=0xFFCC9045;color=0xFFFFF4E4;}
        if(type.equals("APK")){tint=0xFF559B4C;color=0xFFEEF9EA;}
        TextView v=text(icon,22,tint,true);v.setGravity(Gravity.CENTER);v.setBackground(bg(color,12));return v;
    }
    private String categoryIcon(String c){
        switch(c){case "ფოტოები":return "▧";case "ვიდეოები":return "▶";case "აუდიო":return "♫";case "დოკუმენტები":return "▤";
        case "არქივები":return "▦";case "APK":return "⬡";default:return "◇";}
    }
    private TextView button(String s,int color,boolean bold){TextView t=text(s,15,color,bold);t.setGravity(Gravity.CENTER);return t;}
    private void empty(String message){
        LinearLayout card=vertical();pad(card,18,29,18,29);card.setBackground(outline(WHITE,BORDER,17));
        TextView icon=text("◎",37,PURPLE,true);icon.setGravity(Gravity.CENTER);card.addView(icon);
        TextView m=text(message,13,MUTED,false);m.setGravity(Gravity.CENTER);pad(m,8,12,8,0);card.addView(m);page.addView(card);
    }
    private void filePage(boolean onlyBig){
        heading(onlyBig?"ყველაზე დიდი ფაილები":"ჩემი ფაილები",onlyBig?"იპოვე ფაილები, რომლებიც ყველაზე მეტ ადგილს იკავებს":"მოძებნე, გაფილტრე და დაათვალიერე ფაილები");
        if(result==null){empty("ჯერ დაიწყე სკანირება მთავარ გვერდზე.");return;}
        if(!onlyBig){
            EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(14);e.setHint("ფაილის სახელის ან მისამართის ძიება");
            e.setTextColor(NAVY);e.setHintTextColor(MUTED);e.setBackground(outline(WHITE,BORDER,14));pad(e,15,8,15,8);
            e.setText(search);e.setSelection(search.length());page.addView(e,lp(-1,49));space(page,12);
            HorizontalScrollView chips=new HorizontalScrollView(this);chips.setHorizontalScrollBarEnabled(false);LinearLayout ch=horizontal();
            for(String cat:new String[]{"ყველა","ფოტოები","ვიდეოები","აუდიო","დოკუმენტები","არქივები","APK","სხვა"}){
                TextView t=text(cat,13,category.equals(cat)?WHITE:MUTED,category.equals(cat));t.setGravity(Gravity.CENTER);
                pad(t,15,10,15,10);t.setBackground(bg(category.equals(cat)?PURPLE:WHITE,24));
                LinearLayout.LayoutParams p=lp(-2,-2);p.setMargins(0,0,d(7),0);ch.addView(t,p);
                t.setOnClickListener(v->{category=cat;pageCount=100;render();});
            }
            chips.addView(ch);page.addView(chips);space(page,14);
            LinearLayout results=vertical();page.addView(results);
            e.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int ct,int af){}
                public void onTextChanged(CharSequence s,int start,int before,int count){search=s.toString();pageCount=100;populateFiles(results,false);}
                public void afterTextChanged(Editable s){} });
            populateFiles(results,false);
        }else{
            LinearLayout results=vertical();page.addView(results);populateFiles(results,true);
        }
    }
    private void populateFiles(LinearLayout list,boolean onlyBig){
        list.removeAllViews();
        ArrayList<ScannerEngine.Item> arr=new ArrayList<>();
        String q=search.toLowerCase(Locale.ROOT).trim();
        for(ScannerEngine.Item it:result.files){
            if(!onlyBig && !category.equals("ყველა")&&!category.equals(it.cat))continue;
            if(!onlyBig && !q.isEmpty()&&!it.file.getName().toLowerCase(Locale.ROOT).contains(q)&&!it.file.getAbsolutePath().toLowerCase(Locale.ROOT).contains(q))continue;
            arr.add(it);
        }
        arr.sort((a,b)->Long.compare(b.size,a.size));
        TextView count=text(arr.size()+" შედეგი • დალაგებულია მოცულობით",12,MUTED,false);pad(count,0,0,0,13);list.addView(count);
        if(arr.isEmpty()){TextView none=text("შესაბამისი ფაილები ვერ მოიძებნა.",14,MUTED,false);pad(none,0,15,0,15);list.addView(none);return;}
        int shown=Math.min(pageCount,arr.size());
        for(int i=0;i<shown;i++){
            ScannerEngine.Item it=arr.get(i);LinearLayout row=fileRow(it,false);
            LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=d(8);list.addView(row,p);
        }
        if(shown<arr.size()){
            TextView more=button("მეტის ნახვა ("+(arr.size()-shown)+")",PURPLE,true);more.setBackground(outline(WHITE,BORDER,14));
            list.addView(more,lp(-1,48));more.setOnClickListener(v->{pageCount+=100;populateFiles(list,onlyBig);});
        }
    }
    private LinearLayout fileRow(ScannerEngine.Item it,boolean check){
        LinearLayout row=horizontal();pad(row,11,12,10,12);row.setBackground(outline(WHITE,BORDER,14));
        if(check){CheckBox cb=new CheckBox(this);cb.setButtonTintList(ColorStateList.valueOf(PURPLE));
            cb.setChecked(selected.contains(it.file.getAbsolutePath()));row.addView(cb,lp(42,45));
            cb.setOnCheckedChangeListener((button,checked)->{if(checked)selected.add(it.file.getAbsolutePath());else selected.remove(it.file.getAbsolutePath());});}
        TextView icon=iconText(categoryIcon(it.cat),it.cat);row.addView(icon,lp(43,43));
        LinearLayout details=vertical();pad(details,12,0,6,0);
        TextView name=text(it.file.getName(),14,NAVY,true);name.setMaxLines(2);name.setEllipsize(TextUtils.TruncateAt.MIDDLE);details.addView(name);
        TextView sub=text(size(it.size)+" • "+it.cat,11,MUTED,false);pad(sub,0,4,0,0);details.addView(sub);
        row.addView(details,new LinearLayout.LayoutParams(0,-2,1));row.addView(text("›",23,MUTED,false));
        row.setOnClickListener(v->details(it));return row;
    }
    private void duplicatePage(){
        heading("დუბლიკატები","SHA-256: ფაილები შედარებულია შიგთავსით, არა მხოლოდ სახელით");
        if(result==null){empty("დუბლიკატები გამოჩნდება სკანირების შემდეგ.");return;}
        LinearLayout summary=vertical();pad(summary,18,16,18,16);summary.setBackground(gradient(0xFFEBE9FF,0xFFF8EAF5,17));
        summary.addView(text(size(result.reclaimable)+" დასაზოგი სივრცე",22,NAVY,true));space(summary,4);
        summary.addView(text(result.duplicates.size()+" ჯგუფი • "+result.extraCopies+" დამატებითი ასლი",12,MUTED,false));
        page.addView(summary);space(page,12);
        if(result.duplicates.isEmpty()){empty("იდენტური შიგთავსის მქონე ფაილები არ აღმოჩნდა.");return;}
        TextView pick=button("✓  დამატებითი ასლების მონიშვნა",PURPLE,true);pick.setBackground(outline(WHITE,BORDER,14));page.addView(pick,lp(-1,48));
        pick.setOnClickListener(v->{selected.clear();for(ScannerEngine.Group g:result.duplicates)for(int i=1;i<g.items.size();i++)selected.add(g.items.get(i).file.getAbsolutePath());render();});
        space(page,9);
        if(!selected.isEmpty()){
            TextView del=button("ურნაში გადატანა • "+selected.size()+" ფაილი",WHITE,true);del.setBackground(bg(PINK,14));page.addView(del,lp(-1,48));
            del.setOnClickListener(v->confirmTrash());space(page,13);
        }
        for(ScannerEngine.Group g:result.duplicates){
            LinearLayout card=vertical();pad(card,13,14,13,13);card.setBackground(outline(WHITE,BORDER,17));
            LinearLayout title=horizontal();LinearLayout titleBody=vertical();
            titleBody.addView(text(g.items.get(0).file.getName(),15,NAVY,true));titleBody.addView(text(g.items.size()+" ერთნაირი • "+size(g.reclaimable)+" დასაზოგი",12,MUTED,false));
            title.addView(titleBody,new LinearLayout.LayoutParams(0,-2,1));
            TextView compare=text("შედარება",12,PURPLE,true);pad(compare,9,9,9,9);compare.setBackground(bg(0xFFECEAFF,11));title.addView(compare);
            compare.setOnClickListener(v->compare(g));card.addView(title);space(card,10);
            for(int i=0;i<Math.min(g.items.size(),8);i++){
                ScannerEngine.Item it=g.items.get(i);
                LinearLayout row=fileRow(it,true);LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=d(6);card.addView(row,p);
            }
            if(g.items.size()>8){TextView more=text("და კიდევ "+(g.items.size()-8)+" ფაილი • შედარების ღილაკით ნახვა",12,PURPLE,false);card.addView(more);}
            margin(page,card,0,0,0,12);
        }
    }
    private void compare(ScannerEngine.Group group){
        LinearLayout lay=vertical();pad(lay,12,8,12,8);
        TextView title=text("იდენტური შიგთავსი • SHA-256",14,PURPLE,true);lay.addView(title);space(lay,7);
        ScrollView scroll=new ScrollView(this);LinearLayout items=vertical();
        for(int j=0;j<group.items.size();j++){
            ScannerEngine.Item i=group.items.get(j);
            LinearLayout box=vertical();pad(box,10,10,10,12);box.setBackground(outline(BG,BORDER,13));
            if(i.cat.equals("ფოტოები")){ImageView img=new ImageView(this);img.setAdjustViewBounds(true);img.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                android.graphics.Bitmap bitmap=thumb(i.file,600);if(bitmap!=null){img.setImageBitmap(bitmap);box.addView(img,lp(-1,180));}}
            box.addView(text((j==0?"შესანახი ასლი":"ასლი "+(j+1))+" • "+size(i.size),13,NAVY,true));space(box,6);
            TextView path=text(i.file.getAbsolutePath(),12,MUTED,false);path.setTextIsSelectable(true);box.addView(path);
            TextView open=text("ფაილის გახსნა  ›",13,PURPLE,true);pad(open,0,10,0,3);box.addView(open);
            open.setOnClickListener(v->openFile(i.file));
            LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=d(8);items.addView(box,p);
        }
        scroll.addView(items);lay.addView(scroll,lp(-1,Math.min(510,160*group.items.size()+60)));
        new AlertDialog.Builder(this).setTitle("დუბლიკატების შედარება").setView(lay).setPositiveButton("დახურვა",null).show();
    }
    private void details(ScannerEngine.Item item){
        String text="სახელი: "+item.file.getName()+"\n\nტიპი: "+item.cat+"\nმოცულობა: "+size(item.size)+
            "\nშეცვლილია: "+new SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(new Date(item.modified))+
            "\n\nმისამართი:\n"+item.file.getAbsolutePath();
        new AlertDialog.Builder(this).setTitle("ფაილის დეტალები").setMessage(text)
            .setPositiveButton("გახსნა",(di,w)->openFile(item.file))
            .setNeutralButton("ურნაში",(di,w)->{selected.clear();selected.add(item.file.getAbsolutePath());confirmTrash();})
            .setNegativeButton("დახურვა",null).show();
    }
    private Bitmap thumb(File file,int px){
        try{BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;BitmapFactory.decodeFile(file.getAbsolutePath(),o);
            o.inSampleSize=1;while(o.outWidth/o.inSampleSize>px*2||o.outHeight/o.inSampleSize>px*2)o.inSampleSize*=2;
            o.inJustDecodeBounds=false;return BitmapFactory.decodeFile(file.getAbsolutePath(),o);
        }catch(Exception e){return null;}
    }
    private void openFile(File f){
        try{
            String mime=java.net.URLConnection.guessContentTypeFromName(f.getName());if(mime==null)mime="*/*";
            Uri uri=Uri.parse("content://ge.diskscope.app.files/"+Uri.encode(f.getAbsolutePath()));
            Intent intent=new Intent(Intent.ACTION_VIEW);intent.setDataAndType(uri,mime);intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent,"გახსენი ფაილი"));
        }catch(Exception e){Toast.makeText(this,"ფაილის გახსნა ვერ მოხერხდა",Toast.LENGTH_LONG).show();}
    }
    private void confirmTrash(){
        if(selected.isEmpty())return;
        int n=selected.size();
        new AlertDialog.Builder(this).setTitle("ფაილების ურნაში გადატანა?")
            .setMessage(n+" ფაილი გადავა DiskScope-ის ურნაში. დასაბრუნებლად გამოიყენე განყოფილება „ურნა“.\n\nმონიშნულ ფაილებს შენ თავად ირჩევ.")
            .setNegativeButton("გაუქმება",null).setPositiveButton("გადატანა",(x,y)->trashSelected()).show();
    }
    private void trashSelected(){
        ArrayList<String> targets=new ArrayList<>(selected);selected.clear();
        new Thread(()->{
            int ok=0,fail=0;
            for(String s:targets){File src=new File(s);File root=findRoot(src);
                if(root==null||!src.isFile()){fail++;continue;}
                File trashDir=new File(root,"DiskScopeTrash");
                if(!trashDir.exists()&&!trashDir.mkdirs()){fail++;continue;}
                String unique=System.currentTimeMillis()+"_"+UUID.randomUUID().toString().substring(0,8)+"_"+src.getName();
                File dest=new File(trashDir,unique);
                if(src.renameTo(dest)){
                    getSharedPreferences("trash",MODE_PRIVATE).edit().putString("orig:"+dest.getAbsolutePath(),src.getAbsolutePath()).apply();ok++;
                }else fail++;
            }
            int yes=ok,no=fail;
            ui.post(()->{Toast.makeText(this,"ურნაში: "+yes+" • შეცდომა: "+no,Toast.LENGTH_LONG).show();
                if(result!=null){result=null;category="ყველა";search="";}tab=4;render();});
        },"DiskScope-Trash").start();
    }
    private File findRoot(File src){
        try{String path=src.getCanonicalPath();for(File root:storageRoots()){String base=root.getCanonicalPath();
            if(path.startsWith(base+File.separator))return root;}}catch(Exception ignored){}return null;
    }
    private void trashPage(){
        heading("ნაგვის ურნა","ფაილების აღდგენა ან სამუდამო წაშლა");
        ArrayList<File> trashFiles=new ArrayList<>();long total=0;
        for(File root:storageRoots()){
            File dir=new File(root,"DiskScopeTrash");File[] arr=dir.listFiles();if(arr!=null)for(File f:arr)if(f.isFile()){trashFiles.add(f);total+=f.length();}
        }
        if(trashFiles.isEmpty()){empty("ურნა ცარიელია. სკანირება ფაილებს არასდროს შლის.");return;}
        TextView summary=text(trashFiles.size()+" ფაილი • "+size(total),15,NAVY,true);pad(summary,0,0,0,14);page.addView(summary);
        trashFiles.sort((a,b)->Long.compare(b.lastModified(),a.lastModified()));
        for(File f:trashFiles){
            String original=getSharedPreferences("trash",MODE_PRIVATE).getString("orig:"+f.getAbsolutePath(),null);
            LinearLayout card=vertical();pad(card,14,14,14,14);card.setBackground(outline(WHITE,BORDER,14));
            card.addView(text(original==null?f.getName():new File(original).getName(),14,NAVY,true));
            TextView sub=text(size(f.length())+(original==null?"":" • "+original),11,MUTED,false);sub.setMaxLines(2);sub.setEllipsize(TextUtils.TruncateAt.MIDDLE);card.addView(sub);
            space(card,12);LinearLayout buttons=horizontal();
            TextView restore=button("↶  აღდგენა",PURPLE,true);restore.setBackground(bg(0xFFEEEAFE,12));buttons.addView(restore,new LinearLayout.LayoutParams(0,d(42),1));
            TextView del=button("წაშლა",PINK,true);del.setBackground(bg(0xFFFFEAF2,12));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,d(42),1);p.leftMargin=d(9);buttons.addView(del,p);
            card.addView(buttons);margin(page,card,0,0,0,9);
            restore.setOnClickListener(v->restore(f,original));del.setOnClickListener(v->permanentDelete(f));
        }
    }
    private void restore(File f,String original){
        if(original==null){Toast.makeText(this,"საწყისი მისამართი უცნობია",Toast.LENGTH_LONG).show();return;}
        File dest=new File(original);
        File parent=dest.getParentFile();if(parent!=null&&!parent.exists()&&!parent.mkdirs()){
            Toast.makeText(this,"საწყისი ფოლდერი ვერ შეიქმნა",Toast.LENGTH_LONG).show();return;
        }
        if(dest.exists()){Toast.makeText(this,"საწყის ადგილას უკვე არის იგივე სახელის ფაილი",Toast.LENGTH_LONG).show();return;}
        if(f.renameTo(dest)){
            getSharedPreferences("trash",MODE_PRIVATE).edit().remove("orig:"+f.getAbsolutePath()).apply();
            Toast.makeText(this,"ფაილი აღდგენილია",Toast.LENGTH_SHORT).show();render();
        }else Toast.makeText(this,"აღდგენა ვერ შესრულდა",Toast.LENGTH_LONG).show();
    }
    private void permanentDelete(File f){
        new AlertDialog.Builder(this).setTitle("სამუდამოდ წაშლა?")
            .setMessage("ფაილის დაბრუნება აღარ იქნება შესაძლებელი.\n"+f.getName())
            .setNegativeButton("გაუქმება",null).setPositiveButton("წაშლა",(x,y)->{
                boolean ok=f.delete();if(ok)getSharedPreferences("trash",MODE_PRIVATE).edit().remove("orig:"+f.getAbsolutePath()).apply();
                Toast.makeText(this,ok?"ფაილი წაშლილია":"წაშლა ვერ შესრულდა",Toast.LENGTH_SHORT).show();render();
            }).show();
    }
    private void bottomNav(){
        nav.removeAllViews();
        for(int i=0;i<tabTitles.length;i++){
            final int t=i;LinearLayout cell=vertical();cell.setGravity(Gravity.CENTER);
            TextView icon=text(tabIcons[i],21,tab==i?PURPLE:MUTED,tab==i);icon.setGravity(Gravity.CENTER);cell.addView(icon);
            TextView label=text(tabTitles[i],10,tab==i?PURPLE:MUTED,tab==i);label.setGravity(Gravity.CENTER);label.setSingleLine(true);cell.addView(label);
            if(tab==i)cell.setBackground(bg(0xFFF1EEFF,12));
            nav.addView(cell,new LinearLayout.LayoutParams(0,-1,1));
            cell.setOnClickListener(v->{tab=t;pageCount=100;render();scroll.scrollTo(0,0);});
        }
    }
    private void startScan(){
        if(running)return;
        if(!hasAccess()){requestAccess();return;}
        if(scanRoots.isEmpty()){scanRoots.addAll(storageRoots());}
        running=true;result=null;selected.clear();lastFiles=0;lastFolders=0;lastBytes=0;lastItem="";hashing=false;
        tab=0;render();
        engine.scan(new ArrayList<>(scanRoots),new ScannerEngine.Listener(){
            public void progress(int files,int folders,long bytes,String current,boolean isHashing){
                if(!running)return;lastFiles=files;lastFolders=folders;lastBytes=bytes;lastItem=current;hashing=isHashing;
                if(progressCount!=null)progressCount.setText(files+" ფაილი • "+size(bytes));
                if(progressLabel!=null)progressLabel.setText(current);
            }
            public void complete(ScannerEngine.Result r){
                running=false;result=r;
                if(r.cancelled)Toast.makeText(MainActivity.this,"სკანირება შეჩერებულია — ნაწილობრივი მონაცემები",Toast.LENGTH_LONG).show();
                if(!r.error.isEmpty())new AlertDialog.Builder(MainActivity.this).setTitle("სკანირების შეცდომა").setMessage(r.error).setPositiveButton("გასაგებია",null).show();
                render();
            }
        });
    }
    private boolean hasAccess(){
        if(Build.VERSION.SDK_INT>=30)return Environment.isExternalStorageManager();
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED;
    }
    private void requestAccess(){
        new AlertDialog.Builder(this).setTitle("ფაილებზე წვდომა")
            .setMessage("DiskScope-ს სჭირდება საერთო საცავის ფაილების წაკითხვის ნებართვა, რათა გამოავლინოს დიდი და ერთნაირი ფაილები. მონაცემები ტელეფონიდან არ იგზავნება.")
            .setNegativeButton("გაუქმება",null).setPositiveButton("ნებართვის მიცემა",(dialog,which)->{
                if(Build.VERSION.SDK_INT>=30){
                    try{Intent i=new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,Uri.parse("package:"+getPackageName()));startActivity(i);}
                    catch(Exception ex){startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));}
                }else requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},31);
            }).show();
    }
    private ArrayList<File> storageRoots(){
        LinkedHashMap<String,File> roots=new LinkedHashMap<>();
        File shared=Environment.getExternalStorageDirectory();if(shared!=null&&shared.exists())roots.put(shared.getAbsolutePath(),shared);
        File[] extern=getExternalFilesDirs(null);
        if(extern!=null)for(File dir:extern){if(dir==null)continue;
            String path=dir.getAbsolutePath();int idx=path.indexOf("/Android/");if(idx<0)continue;
            File root=new File(path.substring(0,idx));if(root.exists()&&!roots.containsKey(root.getAbsolutePath()))roots.put(root.getAbsolutePath(),root);
        }
        return new ArrayList<>(roots.values());
    }
    private String scopeTitle(){
        if(scanRoots.size()!=1)return "მთელი ტელეფონის საცავი";
        File chosen=scanRoots.get(0);for(File root:storageRoots())if(chosen.equals(root))return "მთელი ტელეფონის საცავი";
        return chosen.getName()+" • საქაღალდე";
    }
    private void chooseRoot(){
        if(running){Toast.makeText(this,"ჯერ შეაჩერე სკანირება",Toast.LENGTH_SHORT).show();return;}
        ArrayList<File> roots=storageRoots();
        String[] options={"მთელი ტელეფონის საცავი","საქაღალდის არჩევა"};
        new AlertDialog.Builder(this).setTitle("სკანირების არეალი").setItems(options,(dialog,which)->{
            if(which==0){scanRoots.clear();scanRoots.addAll(roots);render();}
            else folderBrowser(null);
        }).show();
    }
    private void folderBrowser(File current){
        ArrayList<File> roots=storageRoots();
        File[] dirs;
        if(current==null)dirs=roots.toArray(new File[0]);
        else {File[] list=current.listFiles(File::isDirectory);dirs=list==null?new File[0]:list;Arrays.sort(dirs,(a,b)->a.getName().compareToIgnoreCase(b.getName()));}
        LinearLayout list=vertical();pad(list,8,6,8,6);
        TextView breadcrumb=text(current==null?"შიდა მეხსიერება / SD ბარათი":current.getAbsolutePath(),12,MUTED,false);
        pad(breadcrumb,10,5,10,10);list.addView(breadcrumb);
        if(current!=null){TextView parent=text("‹  ერთი დონით ზემოთ",14,PURPLE,true);pad(parent,12,12,8,12);list.addView(parent);parent.setOnClickListener(v->folderBrowser(current.getParentFile()==null?null:
            roots.stream().anyMatch(x->x.equals(current))?null:current.getParentFile()));}
        int max=Math.min(200,dirs.length);
        for(int i=0;i<max;i++){
            File folder=dirs[i];TextView item=text("▥  "+folder.getName()+"     ›",14,NAVY,false);pad(item,10,12,8,12);
            list.addView(item);View line=new View(this);line.setBackgroundColor(BORDER);list.addView(line,lp(-1,1));
            item.setOnClickListener(v->folderBrowser(folder));
        }
        if(dirs.length>max)list.addView(text("ნაჩვენებია პირველი "+max+" ფოლდერი",12,MUTED,false));
        ScrollView sc=new ScrollView(this);sc.addView(list);
        AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle("აირჩიე საქაღალდე").setView(sc).setNegativeButton("დახურვა",null);
        if(current!=null)b.setPositiveButton("ამ საქაღალდის არჩევა",(x,y)->{scanRoots.clear();scanRoots.add(current);render();});
        AlertDialog dlg=b.create();dlg.setOnShowListener(v->dlg.getWindow().setLayout(-1,d(580)));dlg.show();
    }
    private String size(long bytes){
        if(bytes<1024)return bytes+" B";
        double v=bytes;String[] units={"B","KB","MB","GB","TB"};int u=0;
        while(v>=1024&&u<units.length-1){v/=1024;u++;}
        return String.format(Locale.US,v>=100?"%.0f %s":"%.1f %s",v,units[u]);
    }
    @Override protected void onResume(){super.onResume();if(page!=null&&!running&&result==null)render();}
    @Override public void onBackPressed(){
        if(tab!=0){tab=0;render();scroll.scrollTo(0,0);}
        else if(running)new AlertDialog.Builder(this).setTitle("სკანირების შეწყვეტა?")
            .setMessage("ფაილები არ შეიცვლება.").setNegativeButton("გაგრძელება",null)
            .setPositiveButton("შეჩერება",(x,y)->engine.cancel()).show();
        else super.onBackPressed();
    }
}
